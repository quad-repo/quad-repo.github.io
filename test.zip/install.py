print("Hi! UwU") 
