import os
import shutil
pat = os.getcwd()
qf = input("Enter quad installation folder:")
os.chdir(qf+"\\packages")
os.mkdir("host")
os.chdir(pat)
shutil.move("localhost.py",qf+"\\packages\\host")
shutil.move("localhost.bat",qf+"\\packages\\host")


os.environ["PATH"] += os.pathsep + qf + "\\packages\\host"
