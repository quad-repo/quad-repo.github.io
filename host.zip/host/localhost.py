from netifaces import interfaces, ifaddresses, AF_INET
from http.server import BaseHTTPRequestHandler, HTTPServer
import pathlib
import os
import sys
from win10toast import ToastNotifier
port = int(sys.argv[1][:-1])
test = os.getcwd()+"\\index.html"
def getLocalIp():
    for ifaceName in interfaces():
        addresses = [i['addr'] for i in ifaddresses(ifaceName).setdefault(AF_INET, [{'addr':'No IP addr'}] )]
        return ' '.join(addresses)
print(getLocalIp())
def h2b(html):
    return bytes(html,"utf-8")
def upServer(file,ip = getLocalIp()):
    class server(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.send_header("Cache-Control", "no-cache, must-revalidate")
            self.send_header("Expires" ,"Sat, 26 Jul 2000 01:00:00 GMT")
            self.send_header("link","<style.css>; rel=stylesheet;")
            self.end_headers()
            fil = open(file,"r")
            for line in fil:
                self.wfile.write(h2b(line))
    toaster = ToastNotifier()
    toaster.show_toast("Hoster","Server started at "+ip+":"+str(port),threaded=True)
    webServer = HTTPServer((ip, port), server)
    webServer.serve_forever()


upServer(test)
